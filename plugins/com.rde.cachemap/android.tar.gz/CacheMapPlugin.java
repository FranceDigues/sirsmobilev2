/**
 * Created by roch dardie on 17/04/15.
 */

import java.io.File;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.app.DownloadManager.Request;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
//import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;


import android.content.Context;

import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaInterface;
import android.util.Log;
import android.provider.Settings;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;


public class CacheMapPlugin extends CordovaPlugin {




    private static final long DOWNLOAD_ID_UNDEFINED = -1;
    private static final String TEMP_DOWNLOAD_FILE_EXTENSION = ".temp";
    private static final long DOWNLOAD_PROGRESS_UPDATE_TIMEOUT = 1000;

    HashMap<String, Download> activDownloads = new HashMap<String, Download>();




    private int percent; //0-100
    private long enqueue;  //do Tableau
    private DownloadManager dm;
    private String StorageDrive;


    /**
     * Constructor.
     */
    public CacheMapPlugin() {

    }
    /**
     * Sets the context of the Command. This can then be used to do things like
     * get file paths associated with the Activity.
     *
     * @param cordova The context of the main Activity.
     * @param webView The CordovaWebView Cordova is running in.
     */
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        Log.v("PluginRDE","Init CacheMapPlugin");
    }
    public boolean execute( String action, JSONArray args, CallbackContext callbackContext) throws JSONException {

        this.dm = (DownloadManager) this.cordova.getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
//        this.StorageDrive = "file:///storage/emulated/0/Android/data/com.ionic.Map03/cache/OSM/essai/";
        this.StorageDrive = "file://storage/emulated/0/Android/data/com.ionic.Map03/cache/OSM/essai/";
        //recuperé le stokage de cordova? moche..
//        StorageDrive =args[1];
        Log.d("PluginRDE","PlugCall");

        if( action.equals("updateCache") )
        {
            Log.d("PluginRDE","updateCache");
            this.runToast("updateCache :");

//                Essai
            this.downloadTile("testUUID", "TestNom", 0,0, 0);

        }
        if( action.equals("initUserData") )
        {
            Log.d("PluginRDE","initUserData");
            this.runToast("initUserData :");
        }


        return true;
    }








    //Methode
    private void runToast(final String a ){
        final int duration = Toast.LENGTH_SHORT;
// Shows a toast
//        Log.v(TAG,"CacheMapPlugin received:"+ action);
        cordova.getActivity().runOnUiThread(new Runnable() {
            public void run() {
                Toast toast = Toast.makeText(cordova.getActivity().getApplicationContext(), a, duration);
                toast.show();


            }
        });

    }





    private void initDlReceiver(){
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                    long downloadId = intent.getLongExtra(
                            DownloadManager.EXTRA_DOWNLOAD_ID, 0);


                }
            }
        };

//        registerReceiver(receiver, new IntentFilter(
//                DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }





    public void downloadTile(String mapUUID, String nom, int x,int y, int z) {

         Log.d("PluginRDE","downloadTile");

//        Download_Uri = Uri.parse(  "http://a.tile.openstreetmap.org/0/0/0.png");
//        Uri.parse(  "http://a.tile.openstreetmap.org" + "/" + z + "/" + x + "/" + y + ".png");

        DownloadManager.Request request = new DownloadManager.Request( Uri.parse(  "http://a.tile.openstreetmap.org" + "/" + z + "/" + x + "/" + y + ".png"));

        //Restrict the types of networks over which this download may proceed.
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
        //Set whether this download may proceed over a roaming connection.
        request.setAllowedOverRoaming(false);
        //Set the title of this download, to be displayed in notifications (if enabled).
//        request.setTitle("My Data Download");
        //Set a description of this download, to be displayed in notifications (if enabled)
        request.setDescription("MiseAJourDuCache");
        //Set the local destination for the downloaded file to a path within the application's external files directory
        request.setDestinationUri(Uri.parse(this.StorageDrive + mapUUID + "/" + nom + "/" + z + "/" + x + "/"+y+".png"));
//        request.setDestinationInExternalFilesDir(this,Environment.DIRECTORY_DOWNLOADS,"osm"+"/"+"essai1"+"/"+"0"+"/"+"0"+"/"+"0"+".png");

        enqueue = dm.enqueue(request);

    }







/**    Repompé    **/


//    @Override
//    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
//        try {
//            if (action.equals("startAsync")) {
//                startAsync(args, callbackContext);
//                return true;
//            }
//            if (action.equals("stop")) {
//                stop(args, callbackContext);
//                return true;
//            }
//            return false; // invalid action
//        } catch (Exception ex) {
//            callbackContext.error(ex.getMessage());
//        }
//        return true;
//    }

    private void startAsync(JSONArray args, CallbackContext callbackContext) throws JSONException {
        if (activDownloads.size() == 0) {
            // required to receive notification when download is completed
            cordova.getActivity().registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        }

        Download curDownload = new Download(args.get(0).toString(), args.get(1).toString(), callbackContext);

        if (activDownloads.containsKey(curDownload.getUriString())) {
            return;
        }

        activDownloads.put(curDownload.getUriString(), curDownload);
        Uri source = Uri.parse(curDownload.getUriString());
        // Uri destination = Uri.parse(this.getTemporaryFilePath());

        // attempt to attach to active download for this file (download started and we close/open the app)
        curDownload.setDownloadId(findActiveDownload(curDownload.getUriString()));

        if (curDownload.getDownloadId() == DOWNLOAD_ID_UNDEFINED) {
            // make sure file does not exist, in other case DownloadManager will fail
            File targetFile = new File(Uri.parse(curDownload.getTempFilePath()).getPath());
            targetFile.delete();

            DownloadManager mgr = (DownloadManager) this.cordova.getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(source);
            request.setTitle("org.apache.cordova.backgroundDownload plugin");
            request.setVisibleInDownloadsUi(false);

            request.setDestinationUri(Uri.parse(curDownload.getTempFilePath()));

            curDownload.setDownloadId(mgr.enqueue(request));

        } else if (checkDownloadCompleted(curDownload.getDownloadId())) {
            return;
        }

//        // custom logic to track file download progress
//        StartProgressTracking(curDownload);
    }

//    private void StartProgressTracking(final Download curDownload) {
//        // already started
//        if (curDownload.getTimerProgressUpdate() != null) {
//            return;
//        }
//        final DownloadManager mgr = (DownloadManager) this.cordova.getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
//
//        curDownload.setTimerProgressUpdate(new Timer());
//        curDownload.getTimerProgressUpdate().schedule(new TimerTask() {
//            @Override
//            public void run() {
//                DownloadManager.Query q = new DownloadManager.Query();
//                q.setFilterById(curDownload.getDownloadId());
//                Cursor cursor = mgr.query(q);
//                if (cursor.moveToFirst()) {
//                    long bytesDownloaded = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
//                    long bytesTotal = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
//                    if (bytesTotal != -1) {
//                        try {
//                            JSONObject jsonProgress = new JSONObject();
//                            jsonProgress.put("bytesReceived", bytesDownloaded);
//                            jsonProgress.put("totalBytesToReceive", bytesTotal);
//                            JSONObject obj = new JSONObject();
//                            obj.put("progress", jsonProgress);
//                            PluginResult progressUpdate = new PluginResult(PluginResult.Status.OK, obj);
//                            progressUpdate.setKeepCallback(true);
//                            curDownload.getCallbackContextDownloadStart().sendPluginResult(progressUpdate);
//                        } catch (JSONException e) {
//                            // TODO Auto-generated catch block
//                            e.printStackTrace();
//                        }
//                    }
//                }
//                cursor.close();
//            }
//        }, DOWNLOAD_PROGRESS_UPDATE_TIMEOUT, DOWNLOAD_PROGRESS_UPDATE_TIMEOUT);
//    }

    private void CleanUp(Download curDownload) {

        if (curDownload.getTimerProgressUpdate() != null) {
            curDownload.getTimerProgressUpdate().cancel();
        }

        if (curDownload.getDownloadId() != DOWNLOAD_ID_UNDEFINED) {
            DownloadManager mgr = (DownloadManager) cordova.getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
            mgr.remove(curDownload.getDownloadId());
        }
        activDownloads.remove(curDownload.getUriString());

        if (activDownloads.size() == 0) {
            try {
                cordova.getActivity().unregisterReceiver(receiver);
            } catch (IllegalArgumentException e) {
                // this is fine, receiver was not registered
            }
        }

    }

    private String getUserFriendlyReason(int reason) {
        String failedReason = "";
        switch (reason) {
            case DownloadManager.ERROR_CANNOT_RESUME:
                failedReason = "ERROR_CANNOT_RESUME";
                break;
            case DownloadManager.ERROR_DEVICE_NOT_FOUND:
                failedReason = "ERROR_DEVICE_NOT_FOUND";
                break;
            case DownloadManager.ERROR_FILE_ALREADY_EXISTS:
                failedReason = "ERROR_FILE_ALREADY_EXISTS";
                break;
            case DownloadManager.ERROR_FILE_ERROR:
                failedReason = "ERROR_FILE_ERROR";
                break;
            case DownloadManager.ERROR_HTTP_DATA_ERROR:
                failedReason = "ERROR_HTTP_DATA_ERROR";
                break;
            case DownloadManager.ERROR_INSUFFICIENT_SPACE:
                failedReason = "ERROR_INSUFFICIENT_SPACE";
                break;
            case DownloadManager.ERROR_TOO_MANY_REDIRECTS:
                failedReason = "ERROR_TOO_MANY_REDIRECTS";
                break;
            case DownloadManager.ERROR_UNHANDLED_HTTP_CODE:
                failedReason = "ERROR_UNHANDLED_HTTP_CODE";
                break;
            case DownloadManager.ERROR_UNKNOWN:
                failedReason = "ERROR_UNKNOWN";
                break;
        }

        return failedReason;
    }

    private void stop(JSONArray args, CallbackContext callbackContext) throws JSONException {

        Download curDownload = activDownloads.get(args.get(0).toString());
        if (curDownload == null) {
            callbackContext.error("download requst not found");
            return;
        }

        DownloadManager mgr = (DownloadManager) cordova.getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
        mgr.remove(curDownload.getDownloadId());
        callbackContext.success();
    }

    private long findActiveDownload(String uri) {

        DownloadManager mgr = (DownloadManager) cordova.getActivity().getSystemService(Context.DOWNLOAD_SERVICE);

        long downloadId = DOWNLOAD_ID_UNDEFINED;

        DownloadManager.Query query = new DownloadManager.Query();
        query.setFilterByStatus(DownloadManager.STATUS_PAUSED | DownloadManager.STATUS_PENDING | DownloadManager.STATUS_RUNNING    | DownloadManager.STATUS_SUCCESSFUL);
        Cursor cur = mgr.query(query);
        int idxId = cur.getColumnIndex(DownloadManager.COLUMN_ID);
        int idxUri = cur.getColumnIndex(DownloadManager.COLUMN_URI);
        for (cur.moveToFirst(); !cur.isAfterLast(); cur.moveToNext()) {
            if (uri.equals(cur.getString(idxUri))) {
                downloadId = cur.getLong(idxId);
                break;
            }
        }
        cur.close();

        return downloadId;
    }

    private Boolean checkDownloadCompleted(long id) {
        DownloadManager mgr = (DownloadManager) this.cordova.getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Query query = new DownloadManager.Query();
        query.setFilterById(id);
        Cursor cur = mgr.query(query);
        int idxStatus = cur.getColumnIndex(DownloadManager.COLUMN_STATUS);
        int idxURI = cur.getColumnIndex(DownloadManager.COLUMN_URI);

        if (cur.moveToFirst()) {
            int status = cur.getInt(idxStatus);
            String uri = cur.getString(idxURI);
            Download curDownload = activDownloads.get(uri);
            if (status == DownloadManager.STATUS_SUCCESSFUL) { // TODO review what else we can have here
                copyTempFileToActualFile(curDownload);
                CleanUp(curDownload);
                return true;
            }
        }
        cur.close();

        return false;
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {

            DownloadManager mgr = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);

            long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            DownloadManager.Query query = new DownloadManager.Query();
            query.setFilterById(downloadId);
            Cursor cursor = mgr.query(query);
            int idxURI = cursor.getColumnIndex(DownloadManager.COLUMN_URI);
            cursor.moveToFirst();
            String uri = cursor.getString(idxURI);

            Download curDownload = activDownloads.get(uri);

            try {
                long receivedID = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
                query.setFilterById(receivedID);
                int idxStatus = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                int idxReason = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);

                if (cursor.moveToFirst()) {
                    int status = cursor.getInt(idxStatus);
                    int reason = cursor.getInt(idxReason);
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        copyTempFileToActualFile(curDownload);
                    } else {
                        curDownload.getCallbackContextDownloadStart().error("Download operation failed with status " + status + " and reason: "    + getUserFriendlyReason(reason));
                    }
                } else {
                    curDownload.getCallbackContextDownloadStart().error("cancelled or terminated");
                }
                cursor.close();
            } catch (Exception ex) {
                curDownload.getCallbackContextDownloadStart().error(ex.getMessage());
            } finally {
                CleanUp(curDownload);
            }
        }
    };

    public void copyTempFileToActualFile(Download curDownload) {
        File sourceFile = new File(Uri.parse(curDownload.getTempFilePath()).getPath());
        File destFile = new File(Uri.parse(curDownload.getFilePath()).getPath());
        if (sourceFile.renameTo(destFile)) {
            curDownload.getCallbackContextDownloadStart().success();
        } else {
            curDownload.getCallbackContextDownloadStart().error("Cannot copy from temporary path to actual path");
        }
    }
/**    Repompé    **/



















}
