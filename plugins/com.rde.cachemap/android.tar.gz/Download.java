import java.util.Timer;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.app.DownloadManager.Request;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
//import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;


import android.content.Context;

import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaInterface;
import android.util.Log;
import android.provider.Settings;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Download {

    private static final long DOWNLOAD_ID_UNDEFINED = -1;
    private static final String TEMP_DOWNLOAD_FILE_EXTENSION = ".temp";
    private static final long DOWNLOAD_PROGRESS_UPDATE_TIMEOUT = 1000;

    private String filePath;
    private String tempFilePath;
    private String uriString;
    private CallbackContext callbackContext; // The callback context from which we were invoked.
    private CallbackContext callbackContextDownloadStart; // The callback context from which we started file download command.
    private long downloadId = DOWNLOAD_ID_UNDEFINED;
    private Timer timerProgressUpdate = null;

    public Download(String uriString, String filePath,
                    CallbackContext callbackContext) {
        this.setUriString(uriString);
        this.setFilePath(filePath);
        this.setTempFilePath(filePath + TEMP_DOWNLOAD_FILE_EXTENSION);
        this.setCallbackContext(callbackContext);
        this.setCallbackContextDownloadStart(callbackContext);
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getUriString() {
        return uriString;
    }

    public void setUriString(String uriString) {
        this.uriString = uriString;
    }

    public String getTempFilePath() {
        return tempFilePath;
    }

    public void setTempFilePath(String tempFilePath) {
        this.tempFilePath = tempFilePath;
    }

    public CallbackContext getCallbackContext() {
        return callbackContext;
    }

    public void setCallbackContext(CallbackContext callbackContext) {
        this.callbackContext = callbackContext;
    }

    public CallbackContext getCallbackContextDownloadStart() {
        return callbackContextDownloadStart;
    }

    public void setCallbackContextDownloadStart(
            CallbackContext callbackContextDownloadStart) {
        this.callbackContextDownloadStart = callbackContextDownloadStart;
    }

    public long getDownloadId() {
        return downloadId;
    }

    public void setDownloadId(long downloadId) {
        this.downloadId = downloadId;
    }

    public Timer getTimerProgressUpdate() {
        return timerProgressUpdate;
    }

    public void setTimerProgressUpdate(Timer TimerProgressUpdate) {
        this.timerProgressUpdate = TimerProgressUpdate;
    };
}